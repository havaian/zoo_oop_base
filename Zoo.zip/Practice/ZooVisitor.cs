﻿using Practice.Interfaces;
using Practice.Models;
using System;

namespace Practice.Service
{
    public class ZooVisitor : IZooObserver
    {
        public string Name { get; set; }

        public void Update(string action, Animal animal)
        {
            Console.WriteLine($"{Name}");
        }
    }
}
