﻿using Practice.Interfaces;
using System;

namespace Practice.Models
{
    public class Monkey : IAnimal
    {
        public string Name { get; set; }
        public void MakeSound()
        {
            Console.WriteLine("*whatever sound monkey does emit*");
        }
    }
}
