﻿using System;
using Practice.Interfaces;

namespace Practice.Models
{
    public class Tortoise : IAnimal
    {
        public string Name { get; set; }
        public void MakeSound()
        {
            Console.WriteLine("*clicks, croaks, crackles, chirps, purrs, and grunts*");
        } 
    }
}
