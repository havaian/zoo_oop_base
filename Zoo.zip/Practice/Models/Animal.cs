﻿using System;

namespace Practice.Models
{
    public class Animal
    {
        public string Name { get; set; }

        public virtual void MakeSound () 
        {
            Console.WriteLine("*makin' a sound*");
        }
    }
}
