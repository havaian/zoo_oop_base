﻿using Practice.Interfaces;
using System;

namespace Practice.Models
{
    public class Lion : IAnimal
    {
        public string Name { get; set; }
        public void MakeSound()
        {
            Console.WriteLine("*roars, growls, snarls*");
        }
    }
}
