﻿using Practice.Interfaces;
using System;

namespace Practice.Models
{
    public class Elephant : IAnimal
    {
        public string Name { get; set; }
        public void MakeSound()
        {
            Console.WriteLine("*growls, squeaks, and snorts*");
        }
    }
}
