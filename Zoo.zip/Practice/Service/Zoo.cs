﻿using Practice.Interfaces;
using Practice.Models;
using System;
using System.Collections.Generic;

namespace Practice.Service
{
    public class Zoo : IZooObservable
    {
        List<ZooVisitor> visitors = new List<ZooVisitor>();
        List<IAnimal> animals = new List<IAnimal>();

        int a = 1;

        public void AddAnimal(IAnimal animal)
        {
            animals.Add(animal);
        }

        public void RemoveAnimal(IAnimal animal) 
        { 
            animals.Remove(animal);
        }

        public void DisplayAnimals() 
        {
            foreach (IAnimal animal in animals)
            {
                Console.Write($"Animal: {a++}\n");
            }
        }

        public void AddObserver(ZooVisitor zooObserver) 
        { 
            visitors.Add(zooObserver);
        }

        public void RemoveObserver(ZooVisitor zooObserver)
        {
            visitors.Remove(zooObserver);
        }

        public void NotifyObserver(Animal animal)
        {
            foreach (var visitor in visitors)
            {
                Console.Write($"Animal: {animal.Name}");
            }
        }
    }
}
