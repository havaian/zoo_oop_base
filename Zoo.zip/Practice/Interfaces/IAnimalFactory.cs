﻿namespace Practice.Interfaces
{
    public interface IAnimalFactory
    {
        IAnimal AddAnimal(string name);
    }
}
