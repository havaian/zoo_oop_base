﻿using Practice.Models;
using Practice.Service;

namespace Practice.Interfaces
{
    public interface IZooObservable 
    {
        void AddObserver(ZooVisitor zooObserver);

        void RemoveObserver(ZooVisitor zooObserver);

        void NotifyObserver(Animal animal);
    }
}
