﻿namespace Practice.Interfaces
{
    public interface IAnimal
    {
        void MakeSound();
    }
}
