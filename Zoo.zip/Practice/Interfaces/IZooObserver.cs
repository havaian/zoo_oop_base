﻿using Practice.Models;

namespace Practice.Interfaces
{
    public interface IZooObserver
    {
        void Update(string action, Animal animal);
    }
}
