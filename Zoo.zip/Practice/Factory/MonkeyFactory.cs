﻿
using Practice.Interfaces;
using Practice.Models;

namespace Practice.Factory
{
    public class MonkeyFactory : IAnimalFactory
    {
        public IAnimal AddAnimal(string name)
        {
            return new Monkey { Name = name };
        }
    }
}
