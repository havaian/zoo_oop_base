﻿using System;

using Practice.Interfaces;
using Practice.Models;

namespace Practice.Factory
{
    public class LionFactory : IAnimalFactory
    {
        public IAnimal AddAnimal(string name)
        {
            return new Lion { Name = name };
        }
    }
}
