﻿using Practice.Interfaces;
using Practice.Models;

namespace Practice.Factory
{
    public class ElephantFactory : IAnimalFactory
    {
        public IAnimal AddAnimal(string name)
        {
            return new Elephant { Name = name };
        }
    }
}
