﻿using Practice.Interfaces;
using Practice.Models;

namespace Practice.Factory
{
    public class TortoiseFactory : IAnimalFactory
    {
        public IAnimal AddAnimal(string name)
        {
            return new Tortoise { Name = name };
        }
    }
}
