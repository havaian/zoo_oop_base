﻿using Practice.Interfaces;
using System;

namespace Practice
{
    public class ZooKeeper
    {
        public void PerformTask(IAnimal animal)
        {
            Console.WriteLine("Task:");
            animal.MakeSound();
        }
    }
}
