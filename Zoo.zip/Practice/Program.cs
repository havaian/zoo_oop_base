﻿using Practice.Factory;
using Practice.Models;
using Practice.Service;
using System;

namespace Practice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var zoo = new Zoo();

            var visitor1 = new ZooVisitor
            {
                Name = "A"
            };
            var visitor2 = new ZooVisitor
            {
                Name = "B"
            };

            zoo.AddObserver(visitor1);
            zoo.AddObserver(visitor2);

            var lionFactory = new LionFactory();
            var elephantFactory = new ElephantFactory();
            var monkeyFactory = new MonkeyFactory();
            var tortoiseFactory = new TortoiseFactory();

            var lion = lionFactory.AddAnimal("Simba");
            var elephant = elephantFactory.AddAnimal("Dumbo");
            var monkey = monkeyFactory.AddAnimal("Bimba");
            var tortoise = tortoiseFactory.AddAnimal("Oogway");

            zoo.AddAnimal(lion);
            zoo.AddAnimal(monkey);
            zoo.AddAnimal(elephant);
            zoo.AddAnimal(tortoise);

            zoo.DisplayAnimals();

            var zooKeeper = new ZooKeeper();

            zooKeeper.PerformTask(lion);
            zooKeeper.PerformTask(monkey);
            zooKeeper.PerformTask(elephant);
            zooKeeper.PerformTask(tortoise);

            Console.ReadLine();
        }
    }
}
